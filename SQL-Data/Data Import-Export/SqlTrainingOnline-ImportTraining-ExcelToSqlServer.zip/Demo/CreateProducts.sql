CREATE TABLE [dbo].[Products2](
	[Product_ID] int NULL,
	[Product_NAME] [varchar](50) NULL,
	[Product_SUBCATEGORY] [varchar](50) NULL,
	[Product_SUBCATEGORY_ID] int NULL,
	[Product_CATEGORY] [varchar](50) NULL,
	[Product_CATEGORY_ID] int NULL,
	[Product_COST] decimal(18,2) NULL,
	[Product_BEGIN_DATE] datetime NULL
)